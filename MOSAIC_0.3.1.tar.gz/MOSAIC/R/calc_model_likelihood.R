#' Compute the total model likelihood
#'
#' This function expects matrices of observed and estimated cases and deaths (size
#' \code{n_locations} x \code{n_time_steps}), plus optional weight vectors for
#' locations and time steps (\code{weights_location} and \code{weights_time}).
#' It automatically selects Poisson or Negative Binomial for each location and outcome
#' based on whether \code{Var(observed) / Mean(observed) >= 1.5}. If the ratio is below
#' 1.5, it uses Poisson; otherwise it uses NegBin. Optional enhanced terms (peak timing,
#' peak magnitude, cumulative total, growth rate, duration, WIS) can be toggled on/off
#' and scaled with per-component weights.
#'
#' @param obs_cases Matrix of observed cases, \code{n_locations} x \code{n_time_steps}.
#' @param est_cases Matrix of estimated cases, same dimension as \code{obs_cases}.
#' @param obs_deaths Matrix of observed deaths, \code{n_locations} x \code{n_time_steps}.
#' @param est_deaths Matrix of estimated deaths, same dimension as \code{obs_deaths}.
#' @param weight_cases Numeric scalar (or \code{NULL}), default \code{NULL} which sets to 1 internally.
#' @param weight_deaths Numeric scalar (or \code{NULL}), default \code{NULL} which sets to 1 internally.
#' @param weights_location Optional numeric vector of length \code{n_locations}, or \code{NULL}.
#'                         If \code{NULL}, all locations are weighted equally.
#' @param weights_time Optional numeric vector of length \code{n_time_steps}, or \code{NULL}.
#'                     If \code{NULL}, all time steps are weighted equally.
#' @param zero_buffer Logical; if \code{TRUE} (default), applies zero buffer to avoid \code{log(0)} and
#'                    rounds scalar Poisson max-terms to the nearest integer to stabilize evaluation.
#' @param verbose Logical; if \code{TRUE}, prints summary messages. Default is \code{FALSE}.
#'
#' @param add_max_terms Logical; include Poisson likelihood on per-location maxima (cases + deaths).
#'                      Default \code{TRUE}.
#' @param add_peak_timing Logical; include Normal likelihood on difference in peak week (obs vs est).
#'                        Default \code{TRUE}.
#' @param add_peak_magnitude Logical; include log-Normal likelihood on ratio of peak magnitudes.
#'                           Default \code{TRUE}.
#' @param add_cumulative_total Logical; include progressive NegBin likelihood on cumulative burden at multiple timepoints.
#'                             Default \code{TRUE}.
#' @param add_growth_rate Logical; include Normal likelihood on difference in exponential growth rate.
#'                        Default \code{TRUE}.
#' @param add_duration Logical; include log-Normal likelihood on epidemic duration (ratio est/obs).
#'                     Default \code{TRUE}.
#' @param add_wis Logical; include a Weighted Interval Score (quantile pinball) penalty computed from
#'                parametric quantiles (Poisson/NegBin) implied by \code{estimated}. Default \code{TRUE}.
#'
#' @param weight_peak_timing Numeric; component weight (default 0.8).
#' @param weight_peak_magnitude Numeric; component weight (default 0.8).
#' @param weight_cumulative_total Numeric; component weight (default 0.5).
#' @param weight_growth_rate Numeric; component weight (default 0.5).
#' @param weight_duration Numeric; component weight (default 0.3).
#' @param weight_wis Numeric; WIS component weight (default 0.8).
#'
#' @param peak_method Character; \code{"smooth"} (3-pt moving average) or \code{"simple"} for peak find.
#'                    Default \code{"smooth"}.
#' @param sigma_peak_time Numeric; SD (weeks) for peak timing Normal likelihood. Default \code{2}.
#' @param sigma_peak_log Numeric; SD on log-scale for peak magnitude likelihood. Default \code{0.5}.
#'
#' @param growth_method Character; \code{"derivative"} or \code{"threshold"} for growth periods. Default \code{"derivative"}.
#' @param growth_aggregation Character; \code{"mean"}, \code{"median"}, or \code{"max"} across periods. Default \code{"mean"}.
#' @param smooth_window Integer; moving-average window (weeks) for derivative smoothing. Default \code{7}.
#' @param sigma_r Numeric; SD for growth-rate Normal likelihood. Default \code{0.2}.
#'
#' @param duration_method Character; \code{"epidemic_periods"}, \code{"main_wave"}, or \code{"above_baseline"}.
#'                        Default \code{"epidemic_periods"}.
#' @param duration_aggregation Character; \code{"mean"}, \code{"total"}, or \code{"max"} across epidemics.
#'                             Default \code{"mean"}.
#' @param sigma_duration_log Numeric; SD on log-scale for duration likelihood. Default \code{0.3}.
#'
#' @param wis_quantiles Numeric vector of quantile probabilities used for the WIS central-interval scoring.
#'                      Default \code{c(0.0275, 0.25, 0.5, 0.75, 0.975)}.
#' @param cumulative_timepoints Numeric vector of timepoints (as fractions of time series length) at which to evaluate
#'                              cumulative totals. Default \code{c(0.25, 0.5, 0.75, 1.0)}.
#'
#' @param enable_guardrails Logical; if \code{TRUE}, performs pre-screening to identify unrealistic predictions
#'                         and return floor likelihood immediately. Default \code{TRUE}.
#' @param floor_likelihood Numeric; floor likelihood value returned when guardrails triggered. Default \code{-1e8}.
#' @param guardrail_verbose Logical; if \code{TRUE}, prints detailed guardrail violation messages. Default \code{FALSE}.
#' @param over_prediction_ratio Numeric; threshold for over-prediction detection (est >= ratio * obs). Default \code{50}.
#' @param under_prediction_ratio Numeric; threshold for severe under-prediction (est < ratio * obs). Default \code{0.02}.
#' @param min_cases_for_epidemic Numeric; minimum observed cases to trigger over-prediction check. Default \code{500}.
#' @param substantial_epidemic Numeric; threshold for missing epidemic detection. Default \code{2000}.
#' @param zero_threshold Numeric; minimum observed total to penalize zero predictions. Default \code{500}.
#' @param negative_correlation_threshold Numeric; correlation threshold below which to trigger guardrail. Default \code{-0.2}.
#' @param max_cases_per_timestep Numeric; maximum reasonable cases per location per timestep. Default \code{1e6}.
#' @param max_deaths_per_timestep Numeric; maximum reasonable deaths per location per timestep. Default \code{1e5}.
#'
#' @return A single numeric value: total log-likelihood across all locations and time steps,
#'         or \code{NA_real_} if all locations contribute nothing.
#' @export
calc_model_likelihood <- function(obs_cases,
                                  est_cases,
                                  obs_deaths,
                                  est_deaths,
                                  weight_cases     = NULL,
                                  weight_deaths    = NULL,
                                  weights_location = NULL,
                                  weights_time     = NULL,
                                  zero_buffer      = TRUE,
                                  verbose          = FALSE,
                                  # toggles
                                  add_max_terms         = TRUE,
                                  add_peak_timing       = TRUE,
                                  add_peak_magnitude    = TRUE,
                                  add_cumulative_total  = TRUE,
                                  add_growth_rate       = TRUE,
                                  add_duration          = TRUE,
                                  add_wis               = TRUE,
                                  # component weights
                                  weight_peak_timing       = 0.8,
                                  weight_peak_magnitude    = 0.8,
                                  weight_cumulative_total  = 0.5,
                                  weight_growth_rate       = 0.5,
                                  weight_duration          = 0.3,
                                  weight_wis               = 0.8,
                                  # peak controls
                                  peak_method      = c("smooth", "simple"),
                                  sigma_peak_time  = 2,
                                  sigma_peak_log   = 0.5,
                                  # growth controls
                                  growth_method      = c("derivative", "threshold"),
                                  growth_aggregation = c("mean","median","max"),
                                  smooth_window      = 7,
                                  sigma_r            = 0.2,
                                  # duration controls
                                  duration_method      = c("epidemic_periods","main_wave","above_baseline"),
                                  duration_aggregation = c("mean","total","max"),
                                  sigma_duration_log   = 0.3,
                                  # WIS quantiles (central intervals + optional median)
                                  wis_quantiles      = c(0.0275, 0.25, 0.5, 0.75, 0.975),
                                  # Cumulative progression timepoints
                                  cumulative_timepoints = c(0.25, 0.5, 0.75, 1.0),
                                  # Likelihood guardrails
                                  enable_guardrails = TRUE,
                                  floor_likelihood = -1e9,
                                  guardrail_verbose = FALSE,
                                  # Guardrail thresholds
                                  over_prediction_ratio = 50,
                                  under_prediction_ratio = 0.02,
                                  min_cases_for_epidemic = 500,
                                  substantial_epidemic = 2000,
                                  zero_threshold = 500,
                                  negative_correlation_threshold = -0.2,
                                  max_cases_per_timestep = 1e6,
                                  max_deaths_per_timestep = 1e5)
{
     # --- basic checks ---
     if (!is.matrix(obs_cases) || !is.matrix(est_cases) ||
         !is.matrix(obs_deaths) || !is.matrix(est_deaths)) {
          stop("all inputs must be matrices.")
     }

     n_locations  <- nrow(obs_cases)
     n_time_steps <- ncol(obs_cases)

     if (any(dim(est_cases)   != c(n_locations, n_time_steps)) ||
         any(dim(obs_deaths)  != c(n_locations, n_time_steps)) ||
         any(dim(est_deaths)  != c(n_locations, n_time_steps))) {
          stop("All matrices must have the same dimensions (n_locations x n_time_steps).")
     }

     if (is.null(weights_location)) weights_location <- rep(1, n_locations)
     if (is.null(weights_time))     weights_time     <- rep(1, n_time_steps)
     if (is.null(weight_cases))     weight_cases     <- 1
     if (is.null(weight_deaths))    weight_deaths    <- 1

     if (length(weights_location) != n_locations) stop("weights_location must match the number of locations.")
     if (length(weights_time)     != n_time_steps) stop("weights_time must match the number of time steps.")
     if (any(weights_location < 0)) stop("All weights_location values must be >= 0.")
     if (any(weights_time < 0))     stop("All weights_time values must be >= 0.")
     if (sum(weights_location) == 0 || sum(weights_time) == 0) stop("weights_location and weights_time must not all be zero.")
     if (weight_cases < 0)  stop("weight_cases must be >= 0.")
     if (weight_deaths < 0) stop("weight_deaths must be >= 0.")

     peak_method        <- match.arg(peak_method)
     growth_method      <- match.arg(growth_method)
     growth_aggregation <- match.arg(growth_aggregation)
     duration_method    <- match.arg(duration_method)
     duration_aggregation <- match.arg(duration_aggregation)

     # --- likelihood guardrails ---
     if (enable_guardrails) {
          guardrail_result <- check_likelihood_guardrails(
               obs_cases = obs_cases,
               est_cases = est_cases,
               obs_deaths = obs_deaths,
               est_deaths = est_deaths,
               floor_ll = floor_likelihood,
               over_prediction_ratio = over_prediction_ratio,
               under_prediction_ratio = under_prediction_ratio,
               min_cases_for_epidemic = min_cases_for_epidemic,
               substantial_epidemic = substantial_epidemic,
               zero_threshold = zero_threshold,
               negative_correlation_threshold = negative_correlation_threshold,
               max_cases_per_timestep = max_cases_per_timestep,
               max_deaths_per_timestep = max_deaths_per_timestep,
               verbose = guardrail_verbose
          )

          if (guardrail_result$status == "FLOOR") {
               if (verbose || guardrail_verbose) {
                    message(sprintf("Likelihood guardrails triggered (%d violations). Returning floor likelihood: %.0f",
                                  length(guardrail_result$violations), floor_likelihood))
               }
               return(floor_likelihood)
          }
     }

     # --- helpers ---
     choose_family <- function(x) {
          x <- as.numeric(x)
          ok <- is.finite(x)
          x  <- x[ok]
          if (length(x) < 2L) return("poisson")
          m <- mean(x, na.rm = TRUE)
          if (!is.finite(m) || m <= 0) return("poisson")
          v <- stats::var(x, na.rm = TRUE)
          vmr <- v / m
          if (!is.finite(vmr)) return("poisson")
          if (vmr >= 1.5) "negbin" else "poisson"
     }

     nb_size_from_obs <- function(x) {
          x <- x[is.finite(x)]
          if (length(x) < 2L) return(Inf)  # treat as Poisson
          m <- mean(x); v <- stats::var(x)
          if (!is.finite(m) || !is.finite(v) || m <= 0 || v <= m) return(Inf)
          k <- (m*m) / (v - m)
          if (!is.finite(k) || k <= 0) Inf else k
     }

     mask_weights <- function(w, obs_vec, est_vec = NULL) {
          w2 <- w
          na_idx <- !is.finite(obs_vec) | (!is.null(est_vec) & !is.finite(est_vec))
          if (any(na_idx)) w2[na_idx] <- 0
          w2
     }

     row_ll <- function(obs_vec, est_vec, w_time, fam, zero_buffer) {
          est_eval <- if (zero_buffer) pmax(est_vec, 1e-12) else est_vec
          w_use    <- mask_weights(w_time, obs_vec, est_eval)
          MOSAIC::calc_log_likelihood(
               observed  = obs_vec,
               estimated = est_eval,
               family    = fam,
               weights   = w_use,
               verbose   = FALSE
          )
     }

     max_ll_poisson <- function(obs_vec, est_vec, zero_buffer) {
          obs_max <- suppressWarnings(max(obs_vec, na.rm = TRUE))
          est_max <- suppressWarnings(max(est_vec, na.rm = TRUE))
          if (!is.finite(obs_max) || !is.finite(est_max)) return(NA_real_)
          if (zero_buffer) {
               obs_max <- pmax(round(obs_max), 0)  # ensure non-negative integer
               est_max <- pmax(est_max, 1e-12)
          }
          MOSAIC::calc_log_likelihood(
               observed  = obs_max,
               estimated = est_max,
               family    = "poisson",
               weights   = NULL,
               verbose   = FALSE
          )
     }

     safe_which_max <- function(x) {
          ix <- which.max(ifelse(is.finite(x), x, -Inf))
          if (length(ix) == 0L) NA_integer_ else ix
     }

     peak_index <- function(x, method = "smooth") {
          if (all(!is.finite(x))) return(NA_integer_)
          if (method == "simple" || length(x) < 3L) return(safe_which_max(x))
          xs <- stats::filter(ifelse(is.finite(x), x, 0), rep(1/3, 3), sides = 2)
          safe_which_max(as.numeric(xs))
     }

     peak_value <- function(x, method = "smooth") {
          if (method == "simple" || length(x) < 3L) {
               suppressWarnings(max(x, na.rm = TRUE))
          } else {
               xs <- stats::filter(ifelse(is.finite(x), x, 0), rep(1/3, 3), sides = 2)
               suppressWarnings(max(xs, na.rm = TRUE))
          }
     }

     ll_cumulative_progressive <- function(obs_vec, est_vec, timepoints = c(0.25, 0.5, 0.75, 1.0)) {
          n <- length(obs_vec)
          total_ll <- 0
          n_valid <- 0

          for (tp in timepoints) {
               end_idx <- max(1, round(n * tp))
               o_cum <- sum(obs_vec[1:end_idx], na.rm = TRUE)
               e_cum <- sum(est_vec[1:end_idx], na.rm = TRUE)

               if (!is.finite(o_cum) || !is.finite(e_cum)) next
               if (o_cum == 0 && e_cum == 0) next

               size_param <- max(o_cum / 3, 1)
               size_param <- min(size_param, 1e4)  # tame extremes
               ll_tp <- stats::dnbinom(round(o_cum), mu = e_cum, size = size_param, log = TRUE)

               if (is.finite(ll_tp)) {
                    total_ll <- total_ll + ll_tp
                    n_valid <- n_valid + 1
               }
          }

          if (n_valid == 0) return(NA_real_)
          total_ll / n_valid  # average across timepoints
     }

     identify_growth_derivative <- function(x, smooth_window = 5, min_derivative = 0.1, min_duration = 3) {
          if (length(x) < 4L) return(list())
          x_clean <- ifelse(is.finite(x), x, 0)
          effective_window <- min(smooth_window, length(x_clean))
          xs <- if (effective_window > 1L && length(x_clean) >= effective_window) {
               stats::filter(x_clean, rep(1/effective_window, effective_window), sides = 2)
          } else x_clean
          d <- diff(xs)
          periods <- list()
          in_g <- FALSE; start <- NA_integer_
          for (i in seq_along(d)) {
               if (is.finite(d[i]) && d[i] > min_derivative) {
                    if (!in_g) { in_g <- TRUE; start <- i }
               } else if (in_g) {
                    len <- i - start
                    if (len >= min_duration) periods[[length(periods) + 1L]] <- c(start, i - 1L)
                    in_g <- FALSE
               }
          }
          if (in_g) {
               len <- length(d) - start + 1L
               if (len >= min_duration) periods[[length(periods) + 1L]] <- c(start, length(d))
          }
          periods
     }

     growth_rate_from_periods <- function(x, periods, agg = "mean") {
          if (length(periods) == 0L) return(NA_real_)
          rates <- numeric(0)
          for (p in periods) {
               s_d <- p[1]; e_d <- p[2]
               s_x <- max(1L, s_d)
               e_x <- min(length(x), e_d + 1L)  # map derivative [s,e] -> series [s,e+1]
               if (e_x - s_x + 1L < 2L) next
               seg <- x[s_x:e_x]
               keep <- is.finite(seg) & seg > 0
               if (sum(keep) < 2L) next
               t  <- seq_len(sum(keep))
               yc <- log(seg[keep])
               fit <- try(stats::lm(yc ~ t), silent = TRUE)
               if (!inherits(fit, "try-error")) {
                    r <- stats::coef(fit)[2]
                    if (is.finite(r) && r > 0) rates <- c(rates, as.numeric(r))
               }
          }
          if (length(rates) == 0L) return(NA_real_)
          switch(agg,
                 mean   = mean(rates),
                 median = stats::median(rates),
                 max    = max(rates))
     }

     identify_epidemic_periods <- function(x, baseline_window = 8, threshold_multiplier = 2) {
          n <- length(x)
          if (n <= baseline_window) return(list(starts = integer(0), ends = integer(0)))

          base  <- rep(NA_real_, n)
          for (i in (baseline_window + 1L):n) {
               base[i] <- mean(x[(i - baseline_window):(i - 1L)], na.rm = TRUE)
          }
          thr   <- base * threshold_multiplier
          above <- is.finite(x) & is.finite(thr) & (x > thr)

          # require two consecutive "above" to sustain an epidemic state
          above2 <- above
          if (n >= 2L) for (i in 2:n) above2[i] <- above[i] & above[i - 1L]

          r <- rle(above2)
          ends   <- cumsum(r$lengths)
          starts <- ends - r$lengths + 1L

          epi_starts <- starts[r$values]
          epi_ends   <- ends[r$values]

          epi_starts <- pmax(epi_starts, baseline_window + 1L)
          epi_ends[epi_ends > n] <- n

          list(starts = as.integer(epi_starts), ends = as.integer(epi_ends))
     }

     epidemic_durations <- function(x) {
          epi <- identify_epidemic_periods(x)
          if (length(epi$starts) == 0) return(integer(0))
          mapply(function(s,e) e - s + 1L, epi$starts, epi$ends)
     }

     main_wave_duration <- function(x, proportion = 0.8) {
          tot <- sum(x, na.rm = TRUE); if (!is.finite(tot) || tot <= 0) return(0L)
          target <- tot * proportion
          n <- length(x); best <- n
          # simple O(n^2) search is OK for weekly horizons
          for (s in seq_len(n)) {
               csum <- 0
               for (e in seq.int(s, n)) {
                    csum <- csum + ifelse(is.finite(x[e]), x[e], 0)
                    if (csum >= target) { best <- min(best, e - s + 1L); break }
               }
          }
          best
     }

     duration_stat <- function(x, method = "epidemic_periods", aggregation = "mean") {
          if (method == "epidemic_periods") {
               d <- epidemic_durations(x)
               if (length(d) == 0) return(0)
               switch(aggregation,
                      mean  = mean(d),
                      total = sum(d),
                      max   = max(d))
          } else if (method == "main_wave") {
               main_wave_duration(x, proportion = 0.8)
          } else {
               # above_baseline (use consistent parameters with epidemic_periods)
               n <- length(x); cnt <- 0L
               baseline_window <- 8
               threshold_multiplier <- 2
               for (i in (baseline_window + 1L):n) {
                    base <- mean(x[(i - baseline_window):(i-1L)], na.rm = TRUE)
                    thr  <- base * threshold_multiplier
                    if (is.finite(x[i]) && x[i] > thr) cnt <- cnt + 1L
               }
               cnt
          }
     }

     # --- WIS (Weighted Interval Score) ---
     compute_wis_parametric_row <- function(y, est, fam, k_size, w_time, probs) {
          # mask weights on any non-finite y/est
          w_use <- w_time
          bad   <- !is.finite(y) | !is.finite(est)
          if (any(bad)) w_use[bad] <- 0
          if (sum(w_use) == 0) return(NA_real_)

          est_eval <- pmax(est, 1e-12)

          qfun <- if (fam == "poisson" || !is.finite(k_size)) {
               function(p) stats::qpois(p, lambda = est_eval)
          } else {
               function(p) stats::qnbinom(p, mu = est_eval, size = k_size)
          }

          probs <- sort(unique(probs))

          # median absolute error term (if median included)
          has_med <- any(abs(probs - 0.5) < 1e-8)
          mae_term <- 0
          if (has_med) {
               q_med <- qfun(0.5)
               mae   <- abs(y - q_med)
               mae_term <- sum(mae * w_use, na.rm = TRUE) / sum(w_use)
          }

          # build symmetric central-interval pairs from available quantiles
          lowers <- probs[probs < 0.5]
          uppers <- probs[probs > 0.5]
          pairs  <- list()
          for (p in lowers) {
               comp <- 1 - p
               if (length(uppers) == 0L) next
               if (comp %in% uppers) {
                    q <- comp
               } else {
                    q <- uppers[which.min(abs(uppers - comp))]
               }
               pairs[[length(pairs) + 1L]] <- c(p, q)
          }

          K <- length(pairs)
          sum_IS <- 0
          if (K > 0) {
               for (pq in pairs) {
                    pL <- pq[1]; pU <- pq[2]
                    qL <- qfun(pL); qU <- qfun(pU)
                    alpha <- 1 - (pU - pL)  # central (1 - alpha) interval
                    width <- qU - qL
                    under <- pmax(0, qL - y) * (2/alpha)
                    over  <- pmax(0, y - qU) * (2/alpha)
                    IS    <- width + under + over
                    contrib <- sum(IS * w_use, na.rm = TRUE) / sum(w_use)
                    sum_IS  <- sum_IS + (alpha/2) * contrib
               }
          }

          denom <- (K + 0.5)
          (mae_term + sum_IS) / denom
     }

     # --- main loop ---
     ll_locations <- rep(NA_real_, n_locations)

     for (j in seq_len(n_locations)) {

          obs_c <- obs_cases[j, ]; est_c <- est_cases[j, ]
          obs_d <- obs_deaths[j, ]; est_d <- est_deaths[j, ]

          fam_c <- choose_family(obs_c)
          fam_d <- choose_family(obs_d)

          # NB sizes (per location, from observed, used only if fam == "negbin")
          k_c <- nb_size_from_obs(obs_c)
          k_d <- nb_size_from_obs(obs_d)

          have_cases  <- any(is.finite(obs_c))
          have_deaths <- any(is.finite(obs_d))

          # initialize
          ll_cases <- ll_deaths <- 0
          ll_max_cases <- ll_max_deaths <- 0
          ll_peak_time_c <- ll_peak_time_d <- 0
          ll_peak_mag_c  <- ll_peak_mag_d  <- 0
          ll_cum_tot_c   <- ll_cum_tot_d   <- 0
          ll_growth_c    <- ll_growth_d    <- 0
          ll_duration_c  <- ll_duration_d  <- 0
          ll_wis_cases   <- 0
          ll_wis_deaths  <- 0

          # core time series
          if (have_cases)  ll_cases  <- row_ll(obs_c, est_c, weights_time, fam_c, zero_buffer)
          if (have_deaths) ll_deaths <- row_ll(obs_d, est_d, weights_time, fam_d, zero_buffer)

          # legacy max terms
          if (add_max_terms) {
               if (have_cases)  ll_max_cases  <- max_ll_poisson(obs_c, if (zero_buffer) pmax(est_c,1e-12) else est_c, zero_buffer)
               if (have_deaths) ll_max_deaths <- max_ll_poisson(obs_d, if (zero_buffer) pmax(est_d,1e-12) else est_d, zero_buffer)
          }

          # peaks: timing
          if (add_peak_timing) {
               if (have_cases) {
                    tp_obs <- peak_index(obs_c, peak_method); tp_est <- peak_index(est_c, peak_method)
                    if (is.finite(tp_obs) && is.finite(tp_est)) {
                         ll_peak_time_c <- stats::dnorm(tp_est - tp_obs, mean = 0, sd = sigma_peak_time, log = TRUE)
                    }
               }
               if (have_deaths) {
                    tp_obs <- peak_index(obs_d, peak_method); tp_est <- peak_index(est_d, peak_method)
                    if (is.finite(tp_obs) && is.finite(tp_est)) {
                         ll_peak_time_d <- stats::dnorm(tp_est - tp_obs, mean = 0, sd = sigma_peak_time, log = TRUE)
                    }
               }
          }

          # peaks: magnitude
          if (add_peak_magnitude) {
               if (have_cases) {
                    pv_obs <- peak_value(obs_c, peak_method); pv_est <- peak_value(est_c, peak_method)
                    if (is.finite(pv_obs) && is.finite(pv_est) && pv_obs > 0 && pv_est > 0) {
                         ll_peak_mag_c <- stats::dnorm(log(pv_est) - log(pv_obs), mean = 0, sd = sigma_peak_log, log = TRUE)
                    }
               }
               if (have_deaths) {
                    pv_obs <- peak_value(obs_d, peak_method); pv_est <- peak_value(est_d, peak_method)
                    if (is.finite(pv_obs) && is.finite(pv_est) && pv_obs > 0 && pv_est > 0) {
                         ll_peak_mag_d <- stats::dnorm(log(pv_est) - log(pv_obs), mean = 0, sd = sigma_peak_log, log = TRUE)
                    }
               }
          }

          # cumulative total (progressive at multiple timepoints)
          if (add_cumulative_total) {
               if (have_cases)  ll_cum_tot_c <- ll_cumulative_progressive(obs_c, est_c, cumulative_timepoints)
               if (have_deaths) ll_cum_tot_d <- ll_cumulative_progressive(obs_d, est_d, cumulative_timepoints)
          }

          # growth rate
          if (add_growth_rate) {
               if (have_cases) {
                    periods_o <- if (growth_method == "derivative")
                         identify_growth_derivative(obs_c, smooth_window = smooth_window) else {
                              epi <- identify_epidemic_periods(obs_c); mapply(c, as.list(epi$starts), as.list(epi$ends), SIMPLIFY = FALSE)
                         }
                    periods_e <- if (growth_method == "derivative")
                         identify_growth_derivative(est_c, smooth_window = smooth_window) else {
                              epi <- identify_epidemic_periods(est_c); mapply(c, as.list(epi$starts), as.list(epi$ends), SIMPLIFY = FALSE)
                         }
                    r_obs <- growth_rate_from_periods(obs_c, periods_o, agg = growth_aggregation)
                    r_est <- growth_rate_from_periods(est_c, periods_e, agg = growth_aggregation)
                    if (is.finite(r_obs) && is.finite(r_est)) {
                         ll_growth_c <- stats::dnorm(r_est - r_obs, mean = 0, sd = sigma_r, log = TRUE)
                    }
               }
               if (have_deaths) {
                    periods_o <- if (growth_method == "derivative")
                         identify_growth_derivative(obs_d, smooth_window = smooth_window) else {
                              epi <- identify_epidemic_periods(obs_d); mapply(c, as.list(epi$starts), as.list(epi$ends), SIMPLIFY = FALSE)
                         }
                    periods_e <- if (growth_method == "derivative")
                         identify_growth_derivative(est_d, smooth_window = smooth_window) else {
                              epi <- identify_epidemic_periods(est_d); mapply(c, as.list(epi$starts), as.list(epi$ends), SIMPLIFY = FALSE)
                         }
                    r_obs <- growth_rate_from_periods(obs_d, periods_o, agg = growth_aggregation)
                    r_est <- growth_rate_from_periods(est_d, periods_e, agg = growth_aggregation)
                    if (is.finite(r_obs) && is.finite(r_est)) {
                         ll_growth_d <- stats::dnorm(r_est - r_obs, mean = 0, sd = sigma_r, log = TRUE)
                    }
               }
          }

          # duration
          if (add_duration) {
               if (have_cases) {
                    d_obs <- duration_stat(obs_c, method = duration_method, aggregation = duration_aggregation)
                    d_est <- duration_stat(est_c, method = duration_method, aggregation = duration_aggregation)
                    if (is.finite(d_obs) && is.finite(d_est) && d_obs > 0 && d_est > 0) {
                         ll_duration_c <- stats::dnorm(log(d_est) - log(d_obs), mean = 0, sd = sigma_duration_log, log = TRUE)
                    }
               }
               if (have_deaths) {
                    d_obs <- duration_stat(obs_d, method = duration_method, aggregation = duration_aggregation)
                    d_est <- duration_stat(est_d, method = duration_method, aggregation = duration_aggregation)
                    if (is.finite(d_obs) && is.finite(d_est) && d_obs > 0 && d_est > 0) {
                         ll_duration_d <- stats::dnorm(log(d_est) - log(d_obs), mean = 0, sd = sigma_duration_log, log = TRUE)
                    }
               }
          }

          # WIS (parametric quantiles) – lower is better -> subtract
          if (add_wis) {
               if (have_cases) {
                    wis_c <- compute_wis_parametric_row(obs_c, est_c, fam_c, k_c, weights_time, wis_quantiles)
                    if (is.finite(wis_c)) ll_wis_cases <- - weight_wis * wis_c
               }
               if (have_deaths) {
                    wis_d <- compute_wis_parametric_row(obs_d, est_d, fam_d, k_d, weights_time, wis_quantiles)
                    if (is.finite(wis_d)) ll_wis_deaths <- - weight_wis * wis_d
               }
          }

          # no outcome at all -> NA
          if (!have_cases && !have_deaths) {
               ll_locations[j] <- NA_real_
               next
          }

          # assemble location total
          ll_loc_core <-
               weight_cases  * (ll_cases  + if (add_max_terms) ll_max_cases  else 0) +
               weight_deaths * (ll_deaths + if (add_max_terms) ll_max_deaths else 0)

          ll_loc_peaks <-
               weight_peak_timing    * (weight_cases * ll_peak_time_c + weight_deaths * ll_peak_time_d) +
               weight_peak_magnitude * (weight_cases * ll_peak_mag_c  + weight_deaths * ll_peak_mag_d)

          ll_loc_cum <-
               weight_cumulative_total * (weight_cases * ll_cum_tot_c + weight_deaths * ll_cum_tot_d)

          ll_loc_dyn <-
               weight_growth_rate * (weight_cases * ll_growth_c + weight_deaths * ll_growth_d) +
               weight_duration    * (weight_cases * ll_duration_c + weight_deaths * ll_duration_d)

          ll_loc_wis <-
               (weight_cases * ll_wis_cases) + (weight_deaths * ll_wis_deaths)

          # include only enabled blocks
          ll_loc_total <- ll_loc_core
          if (add_peak_timing || add_peak_magnitude) ll_loc_total <- ll_loc_total + ll_loc_peaks
          if (add_cumulative_total)                  ll_loc_total <- ll_loc_total + ll_loc_cum
          if (add_growth_rate || add_duration)       ll_loc_total <- ll_loc_total + ll_loc_dyn
          if (add_wis)                                ll_loc_total <- ll_loc_total + ll_loc_wis

          ll_locations[j] <- weights_location[j] * ll_loc_total

          if (verbose) {
               message(sprintf(
                    paste0(
                         "Location %d: core=%.2f | peaks=%.2f | cum=%.2f | dyn=%.2f | wis=%.2f -> weighted=%.2f"
                    ),
                    j, ll_loc_core,
                    if ((add_peak_timing || add_peak_magnitude)) ll_loc_peaks else 0,
                    if (add_cumulative_total) ll_loc_cum else 0,
                    if ((add_growth_rate || add_duration)) ll_loc_dyn else 0,
                    if (add_wis) ll_loc_wis else 0,
                    weights_location[j] * ll_loc_total
               ))
          }
     }

     if (all(is.na(ll_locations))) {
          if (verbose) message("All locations contributed NA — returning NA.")
          return(NA_real_)
     }

     ll_total <- sum(ll_locations, na.rm = TRUE)

     if (verbose) message(sprintf("Overall total log-likelihood: %.2f", ll_total))

     ll_total
}
