#' Calculate Posterior Predictive Check Samples
#'
#' Generates posterior predictive samples by re-running the LASER model with
#' parameter sets drawn from the posterior distribution using importance weights.
#' This enables model validation through comparison of observed data with
#' predictions from the fitted posterior.
#'
#' @param results Data frame containing calibration results with parameter columns,
#'   likelihood values, and importance weights from posterior analysis.
#' @param col_ll Integer. Column index for log-likelihood values.
#' @param col_params Integer vector. Column indices for model parameters.
#' @param col_seed Integer. Column index for random seeds (for reproducibility).
#' @param param_names Optional character vector of parameter names corresponding to col_params.
#'   If NULL, will use column names from results or generate generic names.
#' @param posterior_weights Numeric vector of posterior importance weights.
#'   If NULL, calculates weights from likelihood using Akaike weighting.
#' @param n_posterior_samples Integer. Number of parameter sets to draw from 
#'   posterior (default 100). Higher values give better coverage but increase runtime.
#' @param n_replications Integer. Number of model replications per parameter set
#'   to capture stochastic variability (default 5).
#' @param config_base Base LASER configuration list (from get_location_config).
#' @param priors_base Prior distributions list (from get_location_priors).
#' @param PATHS List of file paths (from get_paths).
#' @param parallel Logical. Whether to run simulations in parallel (default TRUE).
#' @param n_cores Integer. Number of cores for parallel execution (default 4).
#' @param verbose Logical. Whether to print progress messages (default TRUE).
#'
#' @return A list containing:
#'   \itemize{
#'     \item \code{observed}: List with obs_cases and obs_deaths matrices
#'     \item \code{predictions}: List of predicted cases/deaths for each posterior sample
#'     \item \code{summary_stats}: Aggregated prediction statistics (mean, quantiles)
#'     \item \code{posterior_samples}: Parameter sets and weights used
#'     \item \code{diagnostics}: Runtime and convergence information
#'   }
#'
#' @details
#' This function implements posterior predictive checking for Bayesian model validation:
#' \enumerate{
#'   \item Draws parameter sets from posterior using importance sampling weights
#'   \item Re-runs LASER model multiple times per parameter set (captures stochasticity)
#'   \item Collects predicted cases and deaths for comparison with observed data
#'   \item Returns structured results for visualization and diagnostic checking
#' }
#'
#' The posterior predictive distribution represents what the model predicts
#' we should observe, given the data we have seen. Systematic discrepancies
#' between observed and posterior predictive data indicate model misspecification.
#'
#' @examples
#' \dontrun{
#' # After running calibration and calculating posterior distributions
#' ppc_results <- calc_model_ppc(
#'   results = calibration_results,
#'   col_ll = which(names(results) == "likelihood"),
#'   col_params = param_cols,
#'   col_seed = which(names(results) == "seed"),
#'   param_names = names(calibration_results)[param_cols],
#'   posterior_weights = posterior_result$posterior_weights,
#'   n_posterior_samples = 100,
#'   n_replications = 8,
#'   config_base = config_base,
#'   priors_base = priors_base,
#'   PATHS = PATHS
#' )
#' }
#'
#' @export
#' @importFrom parallel makeCluster stopCluster clusterEvalQ clusterExport
#' @importFrom pbapply pblapply
#' @seealso [plot_model_ppc()], [calc_model_posterior_distributions()]
#' @family model-validation
calc_model_ppc <- function(results,
                          col_ll,
                          col_params, 
                          col_seed,
                          param_names = NULL,
                          posterior_weights = NULL,
                          n_posterior_samples = 100,
                          n_replications = 5,
                          config_base,
                          priors_base, 
                          PATHS,
                          parallel = TRUE,
                          n_cores = 4,
                          verbose = TRUE) {
    
    # ============================================================================
    # Input validation
    # ============================================================================
    
    if (!is.data.frame(results)) {
        stop("results must be a data.frame")
    }
    
    if (!is.numeric(col_ll) || length(col_ll) != 1 || col_ll > ncol(results)) {
        stop("col_ll must be a single valid column index")
    }
    
    if (!is.numeric(col_params) || any(col_params > ncol(results))) {
        stop("col_params must be valid column indices")
    }
    
    if (!is.numeric(col_seed) || length(col_seed) != 1 || col_seed > ncol(results)) {
        stop("col_seed must be a single valid column index")
    }
    
    if (n_posterior_samples < 1 || n_replications < 1) {
        stop("n_posterior_samples and n_replications must be positive integers")
    }
    
    # Setup parameter names
    if (is.null(param_names)) {
        if (!is.null(colnames(results))) {
            param_names <- colnames(results)[col_params]
        } else {
            param_names <- paste0("param_", col_params)
        }
    } else {
        if (length(param_names) != length(col_params)) {
            stop("param_names length must match col_params length")
        }
    }
    
    # Remove rows with missing likelihood
    valid_rows <- !is.na(results[[col_ll]]) & is.finite(results[[col_ll]])
    if (sum(valid_rows) == 0) {
        stop("No valid likelihood values found")
    }
    
    results <- results[valid_rows, ]
    
    if (verbose) {
        cat("Posterior Predictive Check Setup:\n")
        cat("- Valid calibration results:", nrow(results), "\n")
        cat("- Parameters:", length(col_params), "\n") 
        cat("- Posterior samples:", n_posterior_samples, "\n")
        cat("- Replications per sample:", n_replications, "\n")
        cat("- Total model runs:", n_posterior_samples * n_replications, "\n")
    }
    
    # ============================================================================
    # Calculate or validate posterior weights
    # ============================================================================
    
    if (is.null(posterior_weights)) {
        if (verbose) cat("Calculating Akaike weights from likelihood...\n")
        
        # Calculate delta AIC and Akaike weights
        max_ll <- max(results[[col_ll]], na.rm = TRUE)
        delta_aic <- -2 * (results[[col_ll]] - max_ll)
        posterior_weights <- exp(-0.5 * delta_aic)
        posterior_weights <- posterior_weights / sum(posterior_weights)
        
    } else {
        if (length(posterior_weights) != nrow(results)) {
            stop("posterior_weights length must match number of valid results")
        }
        # Ensure normalized
        posterior_weights <- posterior_weights / sum(posterior_weights)
    }
    
    # ============================================================================
    # Sample from posterior
    # ============================================================================
    
    if (verbose) cat("Sampling from posterior distribution...\n")
    
    # Sample parameter sets using importance weights
    posterior_indices <- sample(
        x = 1:nrow(results),
        size = n_posterior_samples,
        prob = posterior_weights,
        replace = TRUE
    )
    
    sampled_results <- results[posterior_indices, ]
    sampled_weights <- posterior_weights[posterior_indices]
    
    if (verbose) {
        cat("Posterior sampling diagnostics:\n")
        cat("- Unique parameter sets selected:", length(unique(posterior_indices)), "\n")
        cat("- Weight range:", sprintf("%.2e", min(sampled_weights)), "to", 
            sprintf("%.2e", max(sampled_weights)), "\n")
    }
    
    # ============================================================================
    # Setup parallel computation
    # ============================================================================
    
    run_ppc_sample <- function(sample_idx, sampled_results, n_replications, 
                               config_base, priors_base, PATHS, col_params, col_seed, param_names) {
        
        # Get parameter values and seed for this posterior sample
        param_row <- sampled_results[sample_idx, ]
        base_seed <- param_row[[col_seed]]
        
        # Validate seed
        if (is.na(base_seed) || base_seed <= 0 || base_seed > 2147483647) {
            # Generate valid seed if original is invalid
            base_seed <- sample(1:100000, 1)
            warning(paste("Invalid seed detected, using random seed:", base_seed))
        }
        
        sample_predictions <- list()
        
        for (rep in 1:n_replications) {
            
            # Create unique seed for this replication (avoid overflow)
            rep_seed <- (base_seed + rep * 1000) %% 2147483647
            if (rep_seed <= 0) rep_seed <- rep_seed + 1
            
            tryCatch({
                # Extract parameter values from results row
                param_values <- unlist(param_row[col_params])
                names(param_values) <- param_names
                
                # Extract sampling metadata from config_base if available
                sampling_flags <- extract_sampling_metadata(config_base)
                
                # Reconstruct config using actual posterior parameter values
                # CRITICAL: Use sampling_flags to preserve original sampling intent
                current_config <- convert_matrix_to_config(
                    param_vector = param_values,
                    config_base = config_base,
                    sampling_flags = sampling_flags
                )
                
                # Update seed in config
                current_config$seed <- rep_seed
                
                # Import laser-cholera
                lc <- reticulate::import("laser_cholera.metapop.model")
                
                # Run model with reconstructed parameters
                model <- lc$run_model(paramfile = current_config, quiet = TRUE)
                
                if (!is.null(model) && !is.null(model$results)) {
                    sample_predictions[[rep]] <- list(
                        cases = model$results$expected_cases,
                        deaths = model$results$disease_deaths,
                        seed = rep_seed,
                        rep = rep,
                        parameters = param_values  # Store actual parameters used
                    )
                }
                
            }, error = function(e) {
                if (verbose) {
                    cat("Failed replication", rep, "for sample", sample_idx, ":", e$message, "\n")
                }
                NULL
            })
        }
        
        return(sample_predictions)
    }
    
    # ============================================================================
    # Execute posterior predictive simulations
    # ============================================================================
    
    if (verbose) cat("Running posterior predictive simulations...\n")
    start_time <- Sys.time()
    
    if (parallel && n_cores > 1) {
        
        if (verbose) cat("Setting up parallel cluster with", n_cores, "cores...\n")
        
        cl <- parallel::makeCluster(n_cores, type = "PSOCK")
        
        parallel::clusterEvalQ(cl, {
            library(MOSAIC)
            library(reticulate)
        })
        
        parallel::clusterExport(cl, c("sampled_results", "n_replications", 
                                     "config_base", "priors_base", "PATHS",
                                     "col_params", "col_seed", "param_names", 
                                     "run_ppc_sample", "convert_matrix_to_config", "verbose"),
                               envir = environment())
        
        # Run simulations in parallel
        all_predictions <- pbapply::pblapply(
            1:n_posterior_samples, 
            function(i) run_ppc_sample(i, sampled_results, n_replications,
                                      config_base, priors_base, PATHS, 
                                      col_params, col_seed, param_names),
            cl = cl
        )
        
        parallel::stopCluster(cl)
        
    } else {
        
        # Sequential execution
        all_predictions <- pbapply::pblapply(
            1:n_posterior_samples,
            function(i) run_ppc_sample(i, sampled_results, n_replications,
                                      config_base, priors_base, PATHS,
                                      col_params, col_seed, param_names)
        )
    }
    
    runtime <- difftime(Sys.time(), start_time, units = "mins")
    if (verbose) cat("Completed in", round(as.numeric(runtime), 2), "minutes\n")
    
    # ============================================================================
    # Process and structure results
    # ============================================================================
    
    if (verbose) cat("Processing prediction results...\n")
    
    # Flatten prediction results
    valid_predictions <- list()
    prediction_count <- 0
    
    for (i in 1:length(all_predictions)) {
        sample_preds <- all_predictions[[i]]
        if (length(sample_preds) > 0) {
            for (rep in 1:length(sample_preds)) {
                if (!is.null(sample_preds[[rep]])) {
                    prediction_count <- prediction_count + 1
                    valid_predictions[[prediction_count]] <- sample_preds[[rep]]
                }
            }
        }
    }
    
    if (length(valid_predictions) == 0) {
        stop("No valid posterior predictive samples generated")
    }
    
    if (verbose) {
        success_rate <- (length(valid_predictions) / (n_posterior_samples * n_replications)) * 100
        cat("Generated", length(valid_predictions), "valid predictions")
        cat(" (", round(success_rate, 1), "% success rate)\n", sep = "")
    }
    
    # Extract observed data from first prediction (should be identical across runs)
    first_config <- sample_parameters(
        PATHS = PATHS,
        priors = priors_base,
        config = config_base,
        seed = sampled_results[[col_seed]][1],
        verbose = FALSE
    )
    
    observed_data <- list(
        cases = first_config$reported_cases,
        deaths = first_config$reported_deaths
    )
    
    # ============================================================================
    # Calculate summary statistics
    # ============================================================================
    
    if (verbose) cat("Calculating summary statistics...\n")
    
    # Organize predictions into arrays for analysis
    n_valid <- length(valid_predictions)
    if (n_valid > 0 && !is.null(valid_predictions[[1]]$cases)) {
        
        cases_dims <- dim(valid_predictions[[1]]$cases)
        deaths_dims <- dim(valid_predictions[[1]]$deaths)
        
        # Initialize arrays: [predictions, locations, time]
        pred_cases_array <- array(NA, dim = c(n_valid, cases_dims[1], cases_dims[2]))
        pred_deaths_array <- array(NA, dim = c(n_valid, deaths_dims[1], deaths_dims[2]))
        
        # Fill arrays
        for (i in 1:n_valid) {
            if (!is.null(valid_predictions[[i]]$cases) && 
                !is.null(valid_predictions[[i]]$deaths)) {
                pred_cases_array[i, , ] <- valid_predictions[[i]]$cases
                pred_deaths_array[i, , ] <- valid_predictions[[i]]$deaths
            }
        }
        
        # Calculate summary statistics across predictions
        summary_stats <- list(
            cases = list(
                mean = apply(pred_cases_array, c(2, 3), mean, na.rm = TRUE),
                median = apply(pred_cases_array, c(2, 3), median, na.rm = TRUE),
                q025 = apply(pred_cases_array, c(2, 3), quantile, 0.025, na.rm = TRUE),
                q975 = apply(pred_cases_array, c(2, 3), quantile, 0.975, na.rm = TRUE),
                sd = apply(pred_cases_array, c(2, 3), sd, na.rm = TRUE)
            ),
            deaths = list(
                mean = apply(pred_deaths_array, c(2, 3), mean, na.rm = TRUE),
                median = apply(pred_deaths_array, c(2, 3), median, na.rm = TRUE),
                q025 = apply(pred_deaths_array, c(2, 3), quantile, 0.025, na.rm = TRUE),
                q975 = apply(pred_deaths_array, c(2, 3), quantile, 0.975, na.rm = TRUE),
                sd = apply(pred_deaths_array, c(2, 3), sd, na.rm = TRUE)
            )
        )
        
    } else {
        summary_stats <- NULL
        warning("Could not calculate summary statistics due to insufficient valid predictions")
    }
    
    # ============================================================================
    # Return structured results
    # ============================================================================
    
    result <- list(
        observed = observed_data,
        predictions = valid_predictions,
        summary_stats = summary_stats,
        posterior_samples = list(
            indices = posterior_indices,
            weights = sampled_weights,
            parameters = sampled_results[, col_params, drop = FALSE]
        ),
        diagnostics = list(
            n_requested_samples = n_posterior_samples,
            n_requested_replications = n_replications, 
            n_valid_predictions = length(valid_predictions),
            success_rate = length(valid_predictions) / (n_posterior_samples * n_replications),
            runtime_minutes = as.numeric(runtime),
            parallel_used = parallel && n_cores > 1,
            n_cores_used = if (parallel && n_cores > 1) n_cores else 1
        )
    )
    
    if (verbose) {
        cat("Posterior predictive check completed!\n")
        cat("Results summary:\n")
        cat("- Valid predictions:", result$diagnostics$n_valid_predictions, "\n")
        cat("- Success rate:", round(result$diagnostics$success_rate * 100, 1), "%\n")
        cat("- Runtime:", round(result$diagnostics$runtime_minutes, 2), "minutes\n")
    }
    
    return(result)
}