#' Plot Posterior Predictive Checks
#'
#' Creates comprehensive diagnostic plots for posterior predictive check results,
#' comparing observed data with posterior predictive distributions across multiple
#' visualization types to assess model adequacy and identify systematic biases.
#'
#' @param ppc_results List object returned by [calc_model_ppc()]. Must contain
#'   observed data, predictions, and summary statistics.
#' @param output_dir Character string specifying directory where plots should be saved.
#'   Directory will be created if it doesn't exist.
#' @param location_names Optional character vector of location names for labeling.
#'   If NULL, uses generic location indices.
#' @param location_codes Optional character vector of location codes (e.g., "ETH") 
#'   for file naming. If NULL, uses location_names or indices.
#' @param time_labels Optional character/Date vector for time axis labels.
#'   If NULL, uses sequential time indices.
#' @param credible_intervals Numeric vector of credible interval levels to display
#'   (default c(0.5, 0.8, 0.95)). Must be between 0 and 1.
#' @param max_predictions Integer. Maximum number of individual prediction traces
#'   to show in timeseries (default 20). Reduces visual clutter.
#' @param plot_width Numeric. Width of saved plots in inches (default 16).
#' @param plot_height Numeric. Height of saved plots in inches (default 14).
#' @param verbose Logical. Whether to print progress messages (default TRUE).
#'
#' @return Invisibly returns a list of ggplot objects for each location:
#'   \itemize{
#'     \item \code{[location]_timeseries}: Time series plots (cases and deaths)
#'     \item \code{[location]_diagnostics}: Diagnostic plots (distributions, scatter, Q-Q, residuals)
#'   }
#'   
#'
#' @details
#' Creates separate timeseries and diagnostic plots for posterior predictive checking:
#'
#' **Timeseries plots** (\code{ppc_timeseries_[location].pdf}):
#' \itemize{
#'   \item Cases and deaths over time with posterior predictive envelopes
#'   \item Individual prediction traces for variability assessment
#'   \item Observed data points overlaid for comparison
#' }
#'
#' **Diagnostic plots** (\code{ppc_diagnostics_[location].pdf}):
#' \enumerate{
#'   \item **Distribution panels**: Density comparison of observed vs predicted marginal distributions
#'   \item **Scatter plots**: Log(observed) vs Log(predicted) with 1:1 reference lines  
#'   \item **Q-Q plots**: Quantile-quantile comparison of empirical distributions
#'   \item **Residuals plots**: Residual vs predicted plots to identify bias patterns
#' }
#'
#' The plots help diagnose:
#' \itemize{
#'   \item **Temporal patterns**: Does model capture epidemic dynamics?
#'   \item **Marginal distributions**: Are predicted counts realistic?
#'   \item **Systematic bias**: Under/over-prediction patterns
#'   \item **Distributional adequacy**: Shape and tail behavior
#' }
#'
#' @examples
#' \dontrun{
#' # After running calc_model_ppc()
#' ppc_plots <- plot_model_ppc(
#'   ppc_results = ppc_results,
#'   output_dir = "model_validation",
#'   location_names = c("Region A", "Region B", "Region C"),
#'   credible_intervals = c(0.5, 0.8, 0.95)
#' )
#' 
#' # View individual panels
#' print(ppc_plots$timeseries)
#' print(ppc_plots$combined)
#' }
#'
#' @export
#' @importFrom ggplot2 ggplot aes geom_line geom_point geom_ribbon geom_density geom_histogram geom_smooth geom_abline geom_qq geom_hline stat_qq scale_color_manual scale_fill_manual facet_wrap theme_minimal theme element_text element_blank labs ggsave xlim ylim annotate theme_void
#' @importFrom dplyr mutate filter bind_rows
#' @importFrom tidyr pivot_longer
#' @importFrom patchwork plot_layout
#' @seealso [calc_model_ppc()], [plot_model_fit()]
#' @family model-validation
plot_model_ppc <- function(ppc_results,
                          output_dir,
                          location_names = NULL,
                          location_codes = NULL,
                          time_labels = NULL,
                          credible_intervals = c(0.5, 0.8, 0.95),
                          max_predictions = 20,
                          plot_width = 16,
                          plot_height = 14,
                          verbose = TRUE) {
    
    # ============================================================================
    # Input validation
    # ============================================================================
    
    if (!is.list(ppc_results)) {
        stop("ppc_results must be a list from calc_model_ppc()")
    }
    
    required_elements <- c("observed", "predictions", "summary_stats")
    missing_elements <- setdiff(required_elements, names(ppc_results))
    if (length(missing_elements) > 0) {
        stop("ppc_results missing required elements: ", 
             paste(missing_elements, collapse = ", "))
    }
    
    if (is.null(ppc_results$summary_stats)) {
        stop("Cannot create plots: summary_stats is NULL in ppc_results")
    }
    
    if (missing(output_dir) || is.null(output_dir)) {
        stop("output_dir is required")
    }
    
    # Validate credible intervals
    if (!is.numeric(credible_intervals) || any(credible_intervals <= 0) || any(credible_intervals >= 1)) {
        stop("credible_intervals must be numeric values between 0 and 1")
    }
    credible_intervals <- sort(credible_intervals)
    
    # Create output directory
    if (!dir.exists(output_dir)) {
        dir.create(output_dir, recursive = TRUE)
        if (verbose) message("Created output directory: ", output_dir)
    }
    
    # ============================================================================
    # Extract and prepare data
    # ============================================================================
    
    if (verbose) cat("Preparing data for posterior predictive check plots...\n")
    
    observed_cases <- ppc_results$observed$cases
    observed_deaths <- ppc_results$observed$deaths
    summary_stats <- ppc_results$summary_stats
    predictions <- ppc_results$predictions
    
    # Get dimensions
    n_locations <- nrow(observed_cases)
    n_time <- ncol(observed_cases)
    n_predictions <- length(predictions)
    
    # Setup location and time labels
    if (is.null(location_names)) {
        location_names <- paste("Location", 1:n_locations)
    }
    if (is.null(location_codes)) {
        # Use location names or fallback to indices for file naming
        location_codes <- if (!is.null(location_names)) {
            gsub("[^A-Za-z0-9]", "_", location_names)  # Clean names for filenames
        } else {
            paste0("LOC", 1:n_locations)
        }
    }
    if (is.null(time_labels)) {
        time_labels <- 1:n_time
    }
    
    if (verbose) {
        cat("Data dimensions:\n")
        cat("- Locations:", n_locations, "\n")
        cat("- Time points:", n_time, "\n") 
        cat("- Predictions:", n_predictions, "\n")
    }
    
    # ============================================================================
    # Create Individual Location Plots 
    # ============================================================================
    
    if (verbose) cat("Creating individual location plots...\n")
    
    # Store all plot objects
    location_plots <- list()
    
    # Loop through each location to create individual PPC plots
    for (loc in 1:n_locations) {
        
        if (verbose) cat("Processing location", loc, ":", location_names[loc], "\n")
        
        # ========================================================================
        # Extract location-specific data
        # ========================================================================
        
        # Observed data for this location
        obs_cases_loc <- observed_cases[loc, ]
        obs_deaths_loc <- observed_deaths[loc, ]
        
        # Summary statistics for this location
        pred_cases_mean <- summary_stats$cases$mean[loc, ]
        pred_cases_q025 <- summary_stats$cases$q025[loc, ]
        pred_cases_q975 <- summary_stats$cases$q975[loc, ]
        pred_deaths_mean <- summary_stats$deaths$mean[loc, ]
        pred_deaths_q025 <- summary_stats$deaths$q025[loc, ]
        pred_deaths_q975 <- summary_stats$deaths$q975[loc, ]
        
        # ========================================================================
        # Cases Timeseries (Row 1)
        # ========================================================================
        
        # Prepare cases timeseries data
        cases_ts_data <- data.frame(
            time = time_labels,
            time_numeric = 1:n_time,
            observed = obs_cases_loc,
            predicted_mean = pred_cases_mean,
            predicted_lower = pred_cases_q025,
            predicted_upper = pred_cases_q975,
            stringsAsFactors = FALSE
        )
        
        # Individual prediction traces for cases (subsample for visibility)
        if (n_predictions > max_predictions) {
            pred_indices <- sample(1:n_predictions, max_predictions)
        } else {
            pred_indices <- 1:n_predictions
        }
        
        # Extract both cases and deaths traces efficiently in one loop
        cases_traces_list <- list()
        deaths_traces_list <- list()
        trace_id <- 1
        
        for (pred_idx in pred_indices) {
            pred <- predictions[[pred_idx]]
            if (!is.null(pred$cases) && !is.null(pred$deaths)) {
                cases_traces_list[[trace_id]] <- data.frame(
                    time = time_labels,
                    time_numeric = 1:n_time,
                    predicted = pred$cases[loc, ],
                    trace_id = trace_id,
                    stringsAsFactors = FALSE
                )
                deaths_traces_list[[trace_id]] <- data.frame(
                    time = time_labels,
                    time_numeric = 1:n_time,
                    predicted = pred$deaths[loc, ],
                    trace_id = trace_id,
                    stringsAsFactors = FALSE
                )
                trace_id <- trace_id + 1
            }
        }
        
        # Handle empty trace lists
        if (length(cases_traces_list) > 0) {
            cases_traces_data <- do.call(rbind, cases_traces_list)
        } else {
            cases_traces_data <- data.frame(
                time = numeric(0), time_numeric = numeric(0), 
                predicted = numeric(0), trace_id = numeric(0)
            )
        }
        
        if (length(deaths_traces_list) > 0) {
            deaths_traces_data <- do.call(rbind, deaths_traces_list)
        } else {
            deaths_traces_data <- data.frame(
                time = numeric(0), time_numeric = numeric(0),
                predicted = numeric(0), trace_id = numeric(0)
            )
        }
        
        # Cases timeseries plot (full width)
        p_cases_ts <- ggplot2::ggplot(cases_ts_data, ggplot2::aes(x = time_numeric))
        
        # Add individual prediction traces if available
        if (nrow(cases_traces_data) > 0) {
            p_cases_ts <- p_cases_ts +
                ggplot2::geom_line(data = cases_traces_data, 
                                  ggplot2::aes(y = predicted, group = trace_id),
                                  alpha = 0.1, color = "steelblue", linewidth = 0.3)
        }
        
        p_cases_ts <- p_cases_ts +
            # Prediction envelope
            ggplot2::geom_ribbon(ggplot2::aes(ymin = predicted_lower, ymax = predicted_upper),
                                alpha = 0.3, fill = "steelblue") +
            # Predicted mean
            ggplot2::geom_line(ggplot2::aes(y = predicted_mean), 
                              color = "steelblue", linewidth = 1, linetype = "dashed") +
            # Observed data points
            ggplot2::geom_point(ggplot2::aes(y = observed), 
                               color = "#2a2a2a", size = 1.8, alpha = 0.8) +
            ggplot2::theme_minimal(base_size = 13) +
            ggplot2::theme(
                panel.grid.minor = ggplot2::element_blank(),
                axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
                plot.title = ggplot2::element_text(size = 16, face = "bold")
            ) +
            ggplot2::labs(
                x = "",  # No x-label on top panel
                y = "Cases",
                title = paste0("Posterior Predictive Check: ", location_names[loc]),
                subtitle = paste0("Black points: observed | Blue ribbon: 95% PI | ", 
                                length(pred_indices), " traces | Dashed: mean")
            )
        
        # ========================================================================
        # Deaths Timeseries (Row 2)  
        # ========================================================================
        
        # Prepare deaths timeseries data
        deaths_ts_data <- data.frame(
            time = time_labels,
            time_numeric = 1:n_time,
            observed = obs_deaths_loc,
            predicted_mean = pred_deaths_mean,
            predicted_lower = pred_deaths_q025,
            predicted_upper = pred_deaths_q975,
            stringsAsFactors = FALSE
        )
        
        # Note: deaths_traces_data already extracted above with cases_traces_data
        
        # Deaths timeseries plot (full width)
        p_deaths_ts <- ggplot2::ggplot(deaths_ts_data, ggplot2::aes(x = time_numeric))
        
        # Add individual prediction traces if available
        if (nrow(deaths_traces_data) > 0) {
            p_deaths_ts <- p_deaths_ts +
                ggplot2::geom_line(data = deaths_traces_data, 
                                  ggplot2::aes(y = predicted, group = trace_id),
                                  alpha = 0.1, color = "darkred", linewidth = 0.3)
        }
        
        p_deaths_ts <- p_deaths_ts +
            # Prediction envelope
            ggplot2::geom_ribbon(ggplot2::aes(ymin = predicted_lower, ymax = predicted_upper),
                                alpha = 0.3, fill = "darkred") +
            # Predicted mean
            ggplot2::geom_line(ggplot2::aes(y = predicted_mean), 
                              color = "darkred", linewidth = 1, linetype = "dashed") +
            # Observed data points
            ggplot2::geom_point(ggplot2::aes(y = observed), 
                               color = "#2a2a2a", size = 1.8, alpha = 0.8) +
            ggplot2::theme_minimal(base_size = 13) +
            ggplot2::theme(
                panel.grid.minor = ggplot2::element_blank(),
                axis.text.x = ggplot2::element_text(angle = 45, hjust = 1)
            ) +
            ggplot2::labs(
                x = "Time",
                y = "Deaths",
                title = "",
                subtitle = ""
            )
        
        # ========================================================================
        # Create location-specific diagnostic data 
        # ========================================================================
        
        # Marginal distribution data for this location
        obs_cases_flat_loc <- obs_cases_loc[!is.na(obs_cases_loc) & obs_cases_loc > 0]
        obs_deaths_flat_loc <- obs_deaths_loc[!is.na(obs_deaths_loc) & obs_deaths_loc > 0]
        
        # Sample predictions for this location
        pred_sample_size <- min(n_predictions, 1000)
        pred_sample_indices <- sample(1:n_predictions, pred_sample_size)
        
        pred_cases_flat_loc <- c()
        pred_deaths_flat_loc <- c()
        
        for (idx in pred_sample_indices) {
            pred <- predictions[[idx]]
            if (!is.null(pred$cases) && !is.null(pred$deaths)) {
                pred_cases_flat_loc <- c(pred_cases_flat_loc, pred$cases[loc, ])
                pred_deaths_flat_loc <- c(pred_deaths_flat_loc, pred$deaths[loc, ])
            }
        }
        
        # Remove NAs and zeros
        pred_cases_flat_loc <- pred_cases_flat_loc[!is.na(pred_cases_flat_loc) & pred_cases_flat_loc > 0]
        pred_deaths_flat_loc <- pred_deaths_flat_loc[!is.na(pred_deaths_flat_loc) & pred_deaths_flat_loc > 0]
        
        # ========================================================================
        # Create diagnostic panels for this location
        # ========================================================================
        
        # Cases distribution panel with better validation
        obs_cases_valid <- obs_cases_flat_loc[!is.na(obs_cases_flat_loc) & is.finite(obs_cases_flat_loc)]
        pred_cases_valid <- pred_cases_flat_loc[!is.na(pred_cases_flat_loc) & is.finite(pred_cases_flat_loc)]
        
        if (length(obs_cases_valid) > 1 && length(pred_cases_valid) > 1) {
            cases_dist_data <- rbind(
                data.frame(type = "Observed", value = obs_cases_valid, stringsAsFactors = FALSE),
                data.frame(type = "Predicted", value = pred_cases_valid, stringsAsFactors = FALSE)
            )
            
            p_dist_cases <- ggplot2::ggplot(cases_dist_data, ggplot2::aes(x = log(value + 1), fill = type)) +
                ggplot2::geom_density(alpha = 0.6, position = "identity") +
                ggplot2::scale_fill_manual(values = c("Observed" = "#2a2a2a", "Predicted" = "steelblue")) +
                ggplot2::theme_minimal(base_size = 11) +
                ggplot2::theme(legend.position = "bottom", legend.title = ggplot2::element_blank(), aspect.ratio = 1) +
                ggplot2::labs(x = "Log(Cases + 1)", y = "Density", title = "Cases Distribution")
        } else {
            p_dist_cases <- ggplot2::ggplot() + 
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\ncases data\nfor distribution", size = 3) +
                ggplot2::theme_void() + 
                ggplot2::labs(title = "Cases Distribution") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        # Deaths distribution panel with better validation
        obs_deaths_valid <- obs_deaths_flat_loc[!is.na(obs_deaths_flat_loc) & is.finite(obs_deaths_flat_loc)]
        pred_deaths_valid <- pred_deaths_flat_loc[!is.na(pred_deaths_flat_loc) & is.finite(pred_deaths_flat_loc)]
        
        if (length(obs_deaths_valid) > 1 && length(pred_deaths_valid) > 1) {
            deaths_dist_data <- rbind(
                data.frame(type = "Observed", value = obs_deaths_valid, stringsAsFactors = FALSE),
                data.frame(type = "Predicted", value = pred_deaths_valid, stringsAsFactors = FALSE)
            )
            
            p_dist_deaths <- ggplot2::ggplot(deaths_dist_data, ggplot2::aes(x = log(value + 1), fill = type)) +
                ggplot2::geom_density(alpha = 0.6, position = "identity") +
                ggplot2::scale_fill_manual(values = c("Observed" = "#2a2a2a", "Predicted" = "darkred")) +
                ggplot2::theme_minimal(base_size = 11) +
                ggplot2::theme(legend.position = "bottom", legend.title = ggplot2::element_blank(), aspect.ratio = 1) +
                ggplot2::labs(x = "Log(Deaths + 1)", y = "Density", title = "Deaths Distribution")
        } else {
            p_dist_deaths <- ggplot2::ggplot() +
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\ndeaths data\nfor distribution", size = 3) +
                ggplot2::theme_void() + 
                ggplot2::labs(title = "Deaths Distribution") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        # Scatter plots (observed vs predicted) with better validation
        scatter_cases_data <- data.frame(
            observed = obs_cases_loc,
            predicted = pred_cases_mean,
            stringsAsFactors = FALSE
        )
        scatter_cases_data <- scatter_cases_data[!is.na(scatter_cases_data$observed) & 
                                               !is.na(scatter_cases_data$predicted) &
                                               is.finite(scatter_cases_data$observed) &
                                               is.finite(scatter_cases_data$predicted) &
                                               scatter_cases_data$observed > 0 & 
                                               scatter_cases_data$predicted > 0, ]
        
        if (nrow(scatter_cases_data) >= 3) {
            p_scatter_cases <- ggplot2::ggplot(scatter_cases_data, 
                                             ggplot2::aes(x = log(observed), y = log(predicted))) +
                ggplot2::geom_point(alpha = 0.7, size = 1.5, color = "steelblue") +
                ggplot2::geom_smooth(method = "lm", se = TRUE, color = "red", linetype = "dashed", linewidth = 0.5) +
                ggplot2::geom_abline(intercept = 0, slope = 1, color = "black", linetype = "solid", linewidth = 0.5) +
                ggplot2::theme_minimal(base_size = 11) +
                ggplot2::theme(aspect.ratio = 1) +
                ggplot2::labs(x = "Log(Observed)", y = "Log(Predicted)", title = "Cases: Obs vs Pred")
        } else {
            p_scatter_cases <- ggplot2::ggplot() +
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\nvalid cases\npairs", size = 3) +
                ggplot2::theme_void() + 
                ggplot2::labs(title = "Cases: Obs vs Pred") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        scatter_deaths_data <- data.frame(
            observed = obs_deaths_loc,
            predicted = pred_deaths_mean,
            stringsAsFactors = FALSE
        )
        scatter_deaths_data <- scatter_deaths_data[!is.na(scatter_deaths_data$observed) & 
                                                 !is.na(scatter_deaths_data$predicted) &
                                                 is.finite(scatter_deaths_data$observed) &
                                                 is.finite(scatter_deaths_data$predicted) &
                                                 scatter_deaths_data$observed > 0 & 
                                                 scatter_deaths_data$predicted > 0, ]
        
        if (nrow(scatter_deaths_data) >= 3) {
            p_scatter_deaths <- ggplot2::ggplot(scatter_deaths_data, 
                                              ggplot2::aes(x = log(observed), y = log(predicted))) +
                ggplot2::geom_point(alpha = 0.7, size = 1.5, color = "darkred") +
                ggplot2::geom_smooth(method = "lm", se = TRUE, color = "red", linetype = "dashed", linewidth = 0.5) +
                ggplot2::geom_abline(intercept = 0, slope = 1, color = "black", linetype = "solid", linewidth = 0.5) +
                ggplot2::theme_minimal(base_size = 11) +
                ggplot2::theme(aspect.ratio = 1) +
                ggplot2::labs(x = "Log(Observed)", y = "Log(Predicted)", title = "Deaths: Obs vs Pred")
        } else {
            p_scatter_deaths <- ggplot2::ggplot() +
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\nvalid deaths\npairs", size = 3) +
                ggplot2::theme_void() + 
                ggplot2::labs(title = "Deaths: Obs vs Pred") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        # Q-Q plots for comparing distributions
        if (length(obs_cases_valid) > 3 && length(pred_cases_valid) > 3) {
            # Sample equal number of points for Q-Q comparison
            n_sample <- min(length(obs_cases_valid), length(pred_cases_valid), 100)
            obs_sample <- sample(obs_cases_valid, n_sample)
            pred_sample <- sample(pred_cases_valid, n_sample)
            
            qq_cases_data <- data.frame(
                theoretical = sort(pred_sample),
                sample = sort(obs_sample)
            )
            
            p_qq_cases <- ggplot2::ggplot(qq_cases_data, ggplot2::aes(x = theoretical, y = sample)) +
                ggplot2::geom_point(alpha = 0.7, size = 1, color = "steelblue") +
                ggplot2::geom_abline(intercept = 0, slope = 1, color = "red", linetype = "dashed") +
                ggplot2::theme_minimal(base_size = 9) +
                ggplot2::theme(aspect.ratio = 1) +
                ggplot2::labs(x = "Predicted Quantiles", y = "Observed Quantiles", title = "Cases: Q-Q Plot")
        } else {
            p_qq_cases <- ggplot2::ggplot() +
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\ndata for\nQ-Q plot", size = 3) +
                ggplot2::theme_void() +
                ggplot2::labs(title = "Cases: Q-Q Plot") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        if (length(obs_deaths_valid) > 3 && length(pred_deaths_valid) > 3) {
            # Sample equal number of points for Q-Q comparison
            n_sample <- min(length(obs_deaths_valid), length(pred_deaths_valid), 100)
            obs_sample <- sample(obs_deaths_valid, n_sample)
            pred_sample <- sample(pred_deaths_valid, n_sample)
            
            qq_deaths_data <- data.frame(
                theoretical = sort(pred_sample),
                sample = sort(obs_sample)
            )
            
            p_qq_deaths <- ggplot2::ggplot(qq_deaths_data, ggplot2::aes(x = theoretical, y = sample)) +
                ggplot2::geom_point(alpha = 0.7, size = 1, color = "darkred") +
                ggplot2::geom_abline(intercept = 0, slope = 1, color = "red", linetype = "dashed") +
                ggplot2::theme_minimal(base_size = 9) +
                ggplot2::theme(aspect.ratio = 1) +
                ggplot2::labs(x = "Predicted Quantiles", y = "Observed Quantiles", title = "Deaths: Q-Q Plot")
        } else {
            p_qq_deaths <- ggplot2::ggplot() +
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\ndata for\nQ-Q plot", size = 3) +
                ggplot2::theme_void() +
                ggplot2::labs(title = "Deaths: Q-Q Plot") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        # Residuals plots (observed - predicted)
        if (nrow(scatter_cases_data) >= 3) {
            resid_cases_data <- data.frame(
                predicted = pred_cases_mean,
                residual = obs_cases_loc - pred_cases_mean,
                stringsAsFactors = FALSE
            )
            resid_cases_data <- resid_cases_data[!is.na(resid_cases_data$predicted) & 
                                               !is.na(resid_cases_data$residual) &
                                               is.finite(resid_cases_data$predicted) &
                                               is.finite(resid_cases_data$residual), ]
            
            p_resid_cases <- ggplot2::ggplot(resid_cases_data, ggplot2::aes(x = predicted, y = residual)) +
                ggplot2::geom_point(alpha = 0.7, size = 1, color = "steelblue") +
                ggplot2::geom_hline(yintercept = 0, color = "red", linetype = "dashed") +
                ggplot2::geom_smooth(method = "loess", se = FALSE, color = "darkblue", linewidth = 0.5) +
                ggplot2::theme_minimal(base_size = 9) +
                ggplot2::theme(aspect.ratio = 1) +
                ggplot2::labs(x = "Predicted", y = "Residual", title = "Cases: Residuals")
        } else {
            p_resid_cases <- ggplot2::ggplot() +
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\ndata for\nresiduals", size = 3) +
                ggplot2::theme_void() +
                ggplot2::labs(title = "Cases: Residuals") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        if (nrow(scatter_deaths_data) >= 3) {
            resid_deaths_data <- data.frame(
                predicted = pred_deaths_mean,
                residual = obs_deaths_loc - pred_deaths_mean,
                stringsAsFactors = FALSE
            )
            resid_deaths_data <- resid_deaths_data[!is.na(resid_deaths_data$predicted) & 
                                                 !is.na(resid_deaths_data$residual) &
                                                 is.finite(resid_deaths_data$predicted) &
                                                 is.finite(resid_deaths_data$residual), ]
            
            p_resid_deaths <- ggplot2::ggplot(resid_deaths_data, ggplot2::aes(x = predicted, y = residual)) +
                ggplot2::geom_point(alpha = 0.7, size = 1, color = "darkred") +
                ggplot2::geom_hline(yintercept = 0, color = "red", linetype = "dashed") +
                ggplot2::geom_smooth(method = "loess", se = FALSE, color = "darkred", linewidth = 0.5) +
                ggplot2::theme_minimal(base_size = 9) +
                ggplot2::theme(aspect.ratio = 1) +
                ggplot2::labs(x = "Predicted", y = "Residual", title = "Deaths: Residuals")
        } else {
            p_resid_deaths <- ggplot2::ggplot() +
                ggplot2::annotate("text", x = 0.5, y = 0.5, label = "Insufficient\ndata for\nresiduals", size = 3) +
                ggplot2::theme_void() +
                ggplot2::labs(title = "Deaths: Residuals") +
                ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1)
        }
        
        # ========================================================================
        # Create and save separate timeseries and diagnostic plots
        # ========================================================================
        
        # Check for patchwork and create plots accordingly
        patchwork_available <- requireNamespace("patchwork", quietly = TRUE)
        
        if (patchwork_available) {
            # Timeseries plot: cases and deaths time series
            timeseries_plot <- p_cases_ts / p_deaths_ts + 
                             patchwork::plot_layout(heights = c(1, 1))
            
            # Diagnostic plots: 2x4 grid of diagnostic panels
            diagnostics_plot <- patchwork::wrap_plots(
                p_dist_cases, p_scatter_cases, p_qq_cases, p_resid_cases,
                p_dist_deaths, p_scatter_deaths, p_qq_deaths, p_resid_deaths,
                nrow = 2, ncol = 4
            )
        } else {
            # Fallback without patchwork - use grid.arrange if available
            if (requireNamespace("gridExtra", quietly = TRUE)) {
                timeseries_plot <- gridExtra::grid.arrange(p_cases_ts, p_deaths_ts, nrow = 2)
                diagnostics_plot <- gridExtra::grid.arrange(
                    p_dist_cases, p_scatter_cases, p_qq_cases, p_resid_cases,
                    p_dist_deaths, p_scatter_deaths, p_qq_deaths, p_resid_deaths,
                    nrow = 2, ncol = 4
                )
            } else {
                # Final fallback - just the cases plot
                timeseries_plot <- p_cases_ts
                diagnostics_plot <- p_dist_cases
                if (verbose) warning("Neither patchwork nor gridExtra available. Using simplified plots.")
            }
        }
        
        # Store plots
        location_plots[[paste0(location_codes[loc], "_timeseries")]] <- timeseries_plot
        location_plots[[paste0(location_codes[loc], "_diagnostics")]] <- diagnostics_plot
        
        # Save timeseries plot
        timeseries_file <- file.path(output_dir, paste0("ppc_timeseries_", location_codes[loc], ".pdf"))
        ggplot2::ggsave(timeseries_file, plot = timeseries_plot, 
                       width = plot_width * 0.75, height = plot_height * 0.5, dpi = 300)
        
        # Save diagnostics plot
        diagnostics_file <- file.path(output_dir, paste0("ppc_diagnostics_", location_codes[loc], ".pdf"))
        ggplot2::ggsave(diagnostics_file, plot = diagnostics_plot, 
                       width = plot_width, height = plot_height * 0.6, dpi = 300)
        
        if (verbose) {
            cat("Saved timeseries:", basename(timeseries_file), "\n")
            cat("Saved diagnostics:", basename(diagnostics_file), "\n")
        }
        
    }  # End of location loop
    
    # ============================================================================
    # Summary and return
    # ============================================================================
    
    if (verbose) {
        cat("Posterior predictive check plots completed!\n")
        cat("Created", length(location_plots), "plots for", n_locations, "locations:\n")
        for (i in 1:length(location_codes)) {
            cat("- Timeseries:", paste0("ppc_timeseries_", location_codes[i], ".pdf"), "\n")
            cat("- Diagnostics:", paste0("ppc_diagnostics_", location_codes[i], ".pdf"), "\n")
        }
        cat("\nFiles saved in:", output_dir, "\n")
    }
    
    # Return all location plots (both timeseries and diagnostics)
    invisible(location_plots)
}
