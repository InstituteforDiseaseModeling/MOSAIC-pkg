#' Calculate Effective Sample Size (ESS)
#'
#' Computes the effective sample size of weighted samples using either
#' the basic weight-based method or the variance-based method from
#' Phillippo et al. (2024).
#'
#' @param w Numeric vector of weights (can be normalized or unnormalized)
#' @param method Character string specifying the ESS calculation method.
#'   Either "basic" (default) for weight-based ESS or "variance" for
#'   variance-based ESS
#' @param x Optional numeric vector or matrix of parameter values. Required
#'   only when method = "variance". If matrix, each column represents a
#'   different parameter
#'
#' @return Scalar ESS value. Larger ESS indicates better effective sample size.
#'   Returns NA if calculation fails.
#'
#' @details
#' The function implements two methods for calculating ESS:
#'
#' \strong{Basic method (weight-based):}
#' \deqn{ESS = \frac{(\sum w_i)^2}{\sum w_i^2}}
#'
#' For normalized weights, this simplifies to:
#' \deqn{ESS = \frac{1}{\sum \tilde{w}_i^2}}
#'
#' This method only requires the weights and measures the effective number
#' of independent samples based on weight concentration.
#'
#' \strong{Variance method (Phillippo et al. 2024):}
#' \deqn{ESS = n \times \frac{Var_{unweighted}(x)}{Var_{weighted}(x)}}
#'
#' This method compares the variance of unweighted samples to weighted samples
#' and requires both weights and parameter values. It provides a more accurate
#' estimate when samples have varying quality or information content.
#'
#' @references
#' Phillippo DM, Dias S, Welton NJ, Caldwell DM, Taske N, Ades AE (2024).
#' "Threshold analysis as an alternative to GRADE for assessing confidence in
#' guideline recommendations based on network meta-analyses."
#' BMC Medical Research Methodology, 24(1), 1-16.
#'
#' @examples
#' # Generate example data
#' set.seed(123)
#' n <- 1000
#' x <- rnorm(n, mean = 5, sd = 2)
#'
#' # Create weights (e.g., from likelihood)
#' loglik <- -0.5 * (x - 6)^2
#' w <- exp(loglik - max(loglik))
#'
#' # Basic ESS
#' ess_basic <- calc_model_ess(w, method = "basic")
#' print(paste("Basic ESS:", round(ess_basic, 2)))
#'
#' # Variance-based ESS
#' ess_var <- calc_model_ess(w, method = "variance", x = x)
#' print(paste("Variance ESS:", round(ess_var, 2)))
#'
#' # With AIC weights
#' ll <- 1000 + rnorm(500, sd = 3)
#' delta <- calc_model_aic_delta(ll)
#' aw <- calc_model_akaike_weights(delta)
#' calc_model_ess(aw$w_tilde)
#'
#' @seealso
#' \code{\link{calc_model_convergence}},
#' \code{\link{calc_model_akaike_weights}},
#' \code{\link{calc_model_weights_gibbs}}
#'
#' @family calibration-metrics
#' @export
calc_model_ess <- function(w, method = c("basic", "variance"), x = NULL) {

  # Input validation
  stopifnot(is.numeric(w))
  method <- match.arg(method)

  # Remove non-finite weights
  finite_idx <- is.finite(w) & w >= 0
  if (sum(finite_idx) == 0) {
    return(NA_real_)
  }
  w <- w[finite_idx]

  # Normalize weights
  s <- sum(w)
  if (s <= 0) return(NA_real_)
  w_norm <- w / s

  if (method == "basic") {
    # Basic weight-based ESS: ESS = 1 / sum(w_i^2)
    denom <- sum(w_norm^2)
    if (denom <= 0) return(NA_real_)
    return(1 / denom)

  } else if (method == "variance") {
    # Variance-based ESS from Phillippo et al. (2024)

    # Check that x is provided
    if (is.null(x)) {
      stop("Parameter values 'x' must be provided when method = 'variance'")
    }

    # Handle subsetting if weights were filtered
    if (is.matrix(x)) {
      x <- x[finite_idx, , drop = FALSE]
    } else {
      x <- x[finite_idx]
    }

    # Check dimensions match
    n_samples <- length(w_norm)
    if (is.matrix(x)) {
      if (nrow(x) != n_samples) {
        stop("Number of rows in x must match length of weights")
      }
    } else {
      if (length(x) != n_samples) {
        stop("Length of x must match length of weights")
      }
      # Convert vector to single-column matrix for consistency
      x <- matrix(x, ncol = 1)
    }

    # Calculate ESS for each parameter (column)
    n_params <- ncol(x)
    ess_values <- numeric(n_params)

    for (j in 1:n_params) {
      x_j <- x[, j]

      # Remove non-finite parameter values
      finite_param <- is.finite(x_j)
      if (sum(finite_param) < 2) {
        ess_values[j] <- NA_real_
        next
      }

      x_j_clean <- x_j[finite_param]
      w_j_clean <- w_norm[finite_param]

      # Renormalize weights after cleaning
      w_j_clean <- w_j_clean / sum(w_j_clean)

      # Calculate unweighted variance (equal weights)
      var_unweighted <- var(x_j_clean)

      # Calculate weighted variance
      mean_weighted <- sum(w_j_clean * x_j_clean)
      var_weighted <- sum(w_j_clean * (x_j_clean - mean_weighted)^2)

      # Calculate ESS for this parameter
      if (var_weighted > 0 && var_unweighted > 0) {
        ess_values[j] <- length(x_j_clean) * (var_unweighted / var_weighted)
      } else {
        ess_values[j] <- NA_real_
      }
    }

    # Return minimum ESS across all parameters (conservative estimate)
    # or mean if user wants average behavior
    ess_final <- min(ess_values, na.rm = TRUE)
    if (!is.finite(ess_final)) {
      return(NA_real_)
    }
    return(ess_final)
  }
}